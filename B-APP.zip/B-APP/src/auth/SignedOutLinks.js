import React from 'react'
import {NavLink} from 'react-router-dom'

const SignedOutLinks = () =>
{
    return(
        <ul className = "navbar-right">


        </ul>
    )
}
export default SignedOutLinks